package com.example.yadavardaro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
