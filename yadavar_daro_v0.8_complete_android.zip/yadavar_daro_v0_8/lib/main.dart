import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

String _dateKey(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

const _blue = Color(0xFF147FF5);
const _bg = Color(0xFFF7F9FC);
final AudioPlayer _globalVoicePlayer = AudioPlayer();
Future<void> _playSavedVoiceGlobal() async {
  final settings = await ReminderSettingsStore.load();
  final path = settings.voicePath;
  if (path != null) {
    await _globalVoicePlayer.play(DeviceFileSource(path));
  }
}

class Medicine {
  Medicine({
    required this.id,
    required this.name,
    required this.dose,
    required this.unit,
    required this.times,
    this.enabled = true,
    this.photoPath,
  });

  final int id;
  String name;
  String dose;
  String unit;
  List<String> times;
  bool enabled;
  String? photoPath;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'dose': dose,
        'unit': unit,
        'times': times,
        'enabled': enabled,
        'photoPath': photoPath,
      };

  factory Medicine.fromJson(Map<String, dynamic> json) {
    final oldTime = json['time'] as String?;
    final rawTimes = json['times'];
    final times = rawTimes is List
        ? rawTimes.map((e) => e.toString()).toList()
        : [oldTime ?? '08:00'];
    return Medicine(
      id: (json['id'] as num).toInt(),
      name: json['name'] as String,
      dose: json['dose'] as String,
      unit: json['unit'] as String,
      times: times..sort(),
      enabled: json['enabled'] as bool? ?? true,
      photoPath: json['photoPath']?.toString(),
    );
  }
}


enum ReminderMode { sound, vibration, soundAndVibration, recordedVoice }

class ReminderSettings {
  ReminderSettings({this.mode = ReminderMode.soundAndVibration, this.voicePath});
  ReminderMode mode;
  String? voicePath;

  Map<String, dynamic> toJson() => {'mode': mode.name, 'voicePath': voicePath};
  factory ReminderSettings.fromJson(Map<String, dynamic> json) {
    final name = json['mode']?.toString();
    final mode = ReminderMode.values.firstWhere((e) => e.name == name, orElse: () => ReminderMode.soundAndVibration);
    return ReminderSettings(mode: mode, voicePath: json['voicePath']?.toString());
  }
}

class ReminderSettingsStore {
  static const key = 'reminder_settings';
  static Future<ReminderSettings> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);
    if (raw == null) return ReminderSettings();
    try { return ReminderSettings.fromJson(jsonDecode(raw) as Map<String, dynamic>); } catch (_) { return ReminderSettings(); }
  }
  static Future<void> save(ReminderSettings value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, jsonEncode(value.toJson()));
  }
}

class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();

  final plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    tz.initializeTimeZones();
    final zone = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(zone.identifier));

    const android = AndroidInitializationSettings('@drawable/ic_stat_medicine');
    const darwin = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    await plugin.initialize(
      settings: InitializationSettings(
        android: android,
        iOS: darwin,
      ),
      onDidReceiveNotificationResponse: (response) async {
        final settings = await ReminderSettingsStore.load();
        if (settings.mode == ReminderMode.recordedVoice && settings.voicePath != null) {
          await _playSavedVoiceGlobal();
        }
      },
    );

    await plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
    await plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestExactAlarmsPermission();
    await plugin
        .resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(alert: true, badge: true, sound: true);
  }

  int notificationId(int medicineId, int timeIndex) => medicineId * 100 + timeIndex;

  Future<void> showTestNotification() async {
    final settings = await ReminderSettingsStore.load();
    final useSound = settings.mode == ReminderMode.sound || settings.mode == ReminderMode.soundAndVibration || settings.mode == ReminderMode.recordedVoice;
    final useVibration = settings.mode == ReminderMode.vibration || settings.mode == ReminderMode.soundAndVibration || settings.mode == ReminderMode.recordedVoice;
    await plugin.show(
      id: 999999,
      title: 'یادآور دارو 💊',
      body: 'این یک اعلان آزمایشی است.',
      notificationDetails: NotificationDetails(
        android: AndroidNotificationDetails(
          'medicine_test_${settings.mode.name}',
          'یادآوری دارو',
          channelDescription: 'آزمایش صدای اعلان و ویبره',
          importance: Importance.high,
          priority: Priority.high,
          playSound: useSound,
          enableVibration: useVibration,
        ),
        iOS: DarwinNotificationDetails(sound: useSound ? 'default' : null),
      ),
    );
  }

  Future<void> scheduleMedicine(Medicine medicine, {ReminderSettings? settings}) async {
    await cancelMedicine(medicine);
    if (!medicine.enabled) return;
    settings ??= await ReminderSettingsStore.load();
    final useSound = settings!.mode == ReminderMode.sound || settings!.mode == ReminderMode.soundAndVibration || settings!.mode == ReminderMode.recordedVoice;
    final useVibration = settings!.mode == ReminderMode.vibration || settings!.mode == ReminderMode.soundAndVibration || settings!.mode == ReminderMode.recordedVoice;

    for (var i = 0; i < medicine.times.length; i++) {
      final parts = medicine.times[i].split(':');
      final hour = int.parse(parts[0]);
      final minute = int.parse(parts[1]);
      final now = tz.TZDateTime.now(tz.local);
      var scheduled = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
      if (scheduled.isBefore(now)) scheduled = scheduled.add(const Duration(days: 1));

      await plugin.zonedSchedule(
        id: notificationId(medicine.id, i),
        title: 'یادآور دارو 💊',
        body: 'زمان مصرف ${medicine.name} — ${medicine.dose} ${medicine.unit}',
        scheduledDate: scheduled,
        notificationDetails: NotificationDetails(
          android: AndroidNotificationDetails(
            'medicine_reminders_${settings!.mode.name}',
            'یادآوری دارو',
            channelDescription: 'یادآوری زمان مصرف داروها',
            importance: Importance.high,
            priority: Priority.high,
            playSound: useSound,
            enableVibration: useVibration,
          ),
          iOS: DarwinNotificationDetails(sound: useSound ? 'default' : null),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        matchDateTimeComponents: DateTimeComponents.time,
      );
    }
  }

  Future<void> cancelMedicine(Medicine medicine) async {
    for (var i = 0; i < medicine.times.length; i++) {
      await plugin.cancel(id: notificationId(medicine.id, i));
    }
    // Extra slots from an older edit are also cleaned up conservatively.
    for (var i = medicine.times.length; i < 20; i++) {
      await plugin.cancel(id: notificationId(medicine.id, i));
    }
  }
}

class MedicineStore {
  static const key = 'medicines';
  static const historyKey = 'consumption_history';

  static Future<List<Medicine>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(key) ?? [];
    return raw
        .map((e) => Medicine.fromJson(jsonDecode(e) as Map<String, dynamic>))
        .toList();
  }

  static Future<void> save(List<Medicine> medicines) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      key,
      medicines.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }

  static Future<List<Map<String, dynamic>>> loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(historyKey) ?? [];
    return raw
        .map((e) => jsonDecode(e) as Map<String, dynamic>)
        .toList();
  }

  static Future<void> saveHistory(List<Map<String, dynamic>> history) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(historyKey, history.map(jsonEncode).toList());
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.instance.init();
  runApp(const YadavarDaroApp());
}

class YadavarDaroApp extends StatelessWidget {
  const YadavarDaroApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'یادآور دارو',
      locale: const Locale('fa'),
      theme: ThemeData(
        useMaterial3: true,
        visualDensity: VisualDensity.standard,
        scaffoldBackgroundColor: _bg,
        colorScheme: ColorScheme.fromSeed(seedColor: _blue),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          labelStyle: const TextStyle(fontSize: 17),
          hintStyle: const TextStyle(fontSize: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Medicine> medicines = [];
  final Map<String, DateTime> consumed = {};
  List<Map<String, dynamic>> history = [];
  int tab = 0;
  ReminderSettings reminderSettings = ReminderSettings();
  final AudioPlayer _voicePlayer = AudioPlayer();

  String doseKey(Medicine m, String time) => '${m.id}_$time';

  @override
  void initState() {
    super.initState();
    _load();
    _loadReminderSettings();
  }

  Future<void> _loadReminderSettings() async {
    final value = await ReminderSettingsStore.load();
    if (mounted) setState(() => reminderSettings = value);
  }

  Future<void> _saveReminderSettings(ReminderSettings value) async {
    reminderSettings = value;
    await ReminderSettingsStore.save(value);
    for (final m in medicines) {
      await NotificationService.instance.scheduleMedicine(m, settings: reminderSettings);
    }
    if (mounted) setState(() {});
  }

  Future<void> _load() async {
    final data = await MedicineStore.load();
    history = await MedicineStore.loadHistory();
    _rebuildTodayConsumed();
    // Start with an empty list for safety; users should only enter medicines
    // that were actually prescribed or recommended to them.
    for (final m in data) {
      await NotificationService.instance.scheduleMedicine(m, settings: reminderSettings);
    }
    data.sort((a, b) => a.times.first.compareTo(b.times.first));
    if (mounted) setState(() => medicines = data);
  }

  void _rebuildTodayConsumed() {
    consumed.clear();
    final today = _dateKey(DateTime.now());
    for (final item in history) {
      if (item['date'] == today && item['consumedAt'] != null) {
        consumed['${item['medicineId']}_${item['time']}'] = DateTime.tryParse(item['consumedAt'].toString()) ?? DateTime.now();
      }
    }
  }

  Future<void> _toggleConsumed(Medicine m, String time) async {
    final key = doseKey(m, time);
    final today = _dateKey(DateTime.now());
    if (consumed.containsKey(key)) {
      consumed.remove(key);
      history.removeWhere((item) => item['date'] == today && item['medicineId'] == m.id && item['time'] == time);
    } else {
      final now = DateTime.now();
      consumed[key] = now;
      history.removeWhere((item) => item['date'] == today && item['medicineId'] == m.id && item['time'] == time);
      history.add({
        'medicineId': m.id,
        'medicineName': m.name,
        'dose': m.dose,
        'unit': m.unit,
        'time': time,
        'date': today,
        'consumedAt': now.toIso8601String(),
      });
    }
    await MedicineStore.saveHistory(history);
    if (mounted) setState(() {});
  }

  Future<void> _clearHistory() async {
    history.clear();
    consumed.clear();
    await MedicineStore.saveHistory(history);
    if (mounted) setState(() {});
  }

  void _openHistory() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => HistoryPage(history: history, onClear: _clearHistory)));
  }

  Future<void> _addMedicine() async {
    final result = await showDialog<Medicine>(
      context: context,
      builder: (_) => const MedicineDialog(),
    );
    if (result == null) return;
    medicines.add(result);
    medicines.sort((a, b) => a.times.first.compareTo(b.times.first));
    await MedicineStore.save(medicines);
    await NotificationService.instance.scheduleMedicine(result, settings: reminderSettings);
    if (mounted) setState(() {});
  }

  Future<void> _editMedicine(Medicine medicine) async {
    final result = await showDialog<Medicine>(
      context: context,
      builder: (_) => MedicineDialog(initial: medicine),
    );
    if (result == null) return;
    final index = medicines.indexWhere((m) => m.id == medicine.id);
    if (index < 0) return;
    medicines[index] = result;
    medicines.sort((a, b) => a.times.first.compareTo(b.times.first));
    await MedicineStore.save(medicines);
    await NotificationService.instance.scheduleMedicine(result, settings: reminderSettings);
    if (mounted) setState(() {});
  }

  Future<void> _delete(Medicine m) async {
    medicines.removeWhere((x) => x.id == m.id);
    await MedicineStore.save(medicines);
    await NotificationService.instance.cancelMedicine(m);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: _bg,
          title: const Row(
            children: [
              Icon(Icons.medication_rounded, color: _blue, size: 32),
              SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('یادآور دارو', style: TextStyle(fontWeight: FontWeight.w800)),
                  Text('سلامت شما، اولویت ماست', style: TextStyle(fontSize: 11, color: Colors.grey)),
                ],
              ),
            ],
          ),
          actions: [
            IconButton(onPressed: _addMedicine, icon: const Icon(Icons.add_circle_outline)),
          ],
        ),
        body: tab == 0
            ? _homeBody()
            : tab == 1
                ? _medicinesBody()
                : _settingsBody(),
        floatingActionButton: tab != 2
            ? FloatingActionButton.extended(
                onPressed: _addMedicine,
                backgroundColor: _blue,
                foregroundColor: Colors.white,
                icon: const Icon(Icons.add),
                label: const Text('افزودن دارو'),
              )
            : null,
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (value) => setState(() => tab = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
            NavigationDestination(icon: Icon(Icons.list_alt_outlined), selectedIcon: Icon(Icons.list_alt), label: 'داروها'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'تنظیمات'),
          ],
        ),
      ),
    );
  }

  Widget _homeBody() {
    final today = DateTime.now();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
      children: [
        Card(
          elevation: 0,
          child: ListTile(
            leading: const Icon(Icons.calendar_today, color: _blue),
            title: const Text('امروز', style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${today.year}/${today.month.toString().padLeft(2, '0')}/${today.day.toString().padLeft(2, '0')}'),
          ),
        ),
        const SizedBox(height: 12),
        const Text('داروهای امروز', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (medicines.isEmpty)
          const Center(child: Padding(padding: EdgeInsets.all(40), child: Text('هنوز دارویی اضافه نشده است.')))
        else
          ...medicines.expand((m) => m.times.map((time) => _medicineDoseCard(m, time))),
      ],
    );
  }

  Widget _medicineDoseCard(Medicine m, String time) {
    final key = doseKey(m, time);
    final isDone = consumed.contains(key);
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        leading: m.photoPath != null
            ? ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(m.photoPath!),
                  width: 56,
                  height: 56,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => CircleAvatar(
                    backgroundColor: isDone ? Colors.green.shade100 : Colors.orange.shade100,
                    child: Icon(isDone ? Icons.check : Icons.access_time, color: isDone ? Colors.green : Colors.orange),
                  ),
                ),
              )
            : CircleAvatar(
                backgroundColor: isDone ? Colors.green.shade100 : Colors.orange.shade100,
                child: Icon(isDone ? Icons.check : Icons.access_time, color: isDone ? Colors.green : Colors.orange),
              ),
        title: Text(m.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        subtitle: Text('${m.dose} ${m.unit}', style: const TextStyle(fontSize: 16)),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(time, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            TextButton(
              onPressed: () => _toggleConsumed(m, time),
              child: Text(isDone ? 'مصرف شد' : 'در انتظار', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _medicinesBody() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('داروهای من', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        ...medicines.map((m) => Card(
              elevation: 0,
              child: ListTile(
                title: Text(m.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${m.dose} ${m.unit} • هر روز • ${m.times.join('، ')}'),
                leading: m.photoPath != null
                    ? ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(m.photoPath!), width: 48, height: 48, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.medication_rounded, color: _blue)))
                    : const Icon(Icons.medication_rounded, color: _blue),
                trailing: PopupMenuButton<String>(
                  onSelected: (value) async {
                    if (value == 'edit') await _editMedicine(m);
                    if (value == 'delete') await _delete(m);
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'edit', child: Text('ویرایش دارو')),
                    PopupMenuItem(value: 'delete', child: Text('حذف دارو')),
                  ],
                ),
              ),
            )),
      ],
    );
  }

  Widget _settingsBody() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      children: [
        const Text('تنظیمات', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        const Text('همه چیز ساده و واضح طراحی شده است.', style: TextStyle(fontSize: 17, color: Colors.black54)),
        const SizedBox(height: 18),
        Card(
          elevation: 0,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              const Text('روش یادآوری', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text('روش مورد علاقه خود را برای اعلان دارو انتخاب کنید.', style: TextStyle(fontSize: 16)),
              const SizedBox(height: 12),
              _reminderChoice(ReminderMode.sound, Icons.volume_up_rounded, 'زنگ گوشی', 'با صدای اعلان گوشی'),
              _reminderChoice(ReminderMode.vibration, Icons.vibration_rounded, 'ویبره', 'بدون صدا، فقط لرزش'),
              _reminderChoice(ReminderMode.soundAndVibration, Icons.notifications_active_rounded, 'زنگ + ویبره', 'هم صدا و هم لرزش'),
              _reminderChoice(ReminderMode.recordedVoice, Icons.mic_rounded, 'صدای ضبط‌شده', reminderSettings.voicePath == null ? 'یک پیام صوتی برای یادآوری ضبط کنید' : 'صدای ضبط‌شده فعال است'),
              if (reminderSettings.voicePath != null) ...[
                const SizedBox(height: 8),
                OutlinedButton.icon(onPressed: _playVoice, icon: const Icon(Icons.play_arrow_rounded), label: const Text('پخش صدای ضبط‌شده')),
              ],
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () async {
                  await NotificationService.instance.showTestNotification();
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اعلان آزمایشی ارسال شد. اگر اعلان دیده نشد، دسترسی اعلان‌های گوشی را بررسی کنید.')));
                  }
                },
                icon: const Icon(Icons.notifications_active_outlined),
                label: const Text('آزمایش اعلان'),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 14),
        Card(
          elevation: 0,
          child: Column(children: [
            ListTile(
              minVerticalPadding: 12,
              leading: const Icon(Icons.history, size: 30),
              title: const Text('تاریخچه مصرف', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
              subtitle: Text('${history.length} نوبت ثبت شده', style: const TextStyle(fontSize: 15)),
              onTap: _openHistory,
            ),
            const Divider(height: 1),
            const ListTile(
              minVerticalPadding: 12,
              leading: Icon(Icons.accessibility_new_rounded, size: 30),
              title: Text('حالت سالمندان', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
              subtitle: Text('دکمه‌ها و نوشته‌های بزرگ فعال هستند', style: TextStyle(fontSize: 15)),
            ),
          ]),
        ),
      ],
    );
  }

  Widget _reminderChoice(ReminderMode mode, IconData icon, String title, String subtitle) {
    final selected = reminderSettings.mode == mode;
    return Card(
      margin: const EdgeInsets.only(top: 8),
      color: selected ? _blue.withOpacity(.08) : Colors.white,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () async {
          if (mode == ReminderMode.recordedVoice) {
            await _recordVoice();
          } else {
            final value = ReminderSettings(mode: mode, voicePath: reminderSettings.voicePath);
            await _saveReminderSettings(value);
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Icon(icon, size: 34, color: selected ? _blue : Colors.black54),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
              const SizedBox(height: 3),
              Text(subtitle, style: const TextStyle(fontSize: 14, color: Colors.black54)),
            ])),
            Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off, size: 30, color: selected ? _blue : Colors.grey),
          ]),
        ),
      ),
    );
  }

  Future<void> _recordVoice() async {
    final recorder = AudioRecorder();
    try {
      if (!await recorder.hasPermission()) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اجازه استفاده از میکروفون داده نشد.')));
        return;
      }
      final dir = await getApplicationDocumentsDirectory();
      final path = '${dir.path}/yadavar_voice.m4a';
      if (mounted) {
        final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
          title: const Text('ضبط صدای یادآوری', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          content: const Text('مثلاً بگویید: «زمان مصرف داروی شماست». سپس دکمه ضبط را بزنید.', style: TextStyle(fontSize: 17)),
          actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('شروع ضبط'))],
        ));
        if (ok != true) return;
      }
      await recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
      if (!mounted) return;
      final stop = await showDialog<bool>(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
        title: const Text('در حال ضبط...', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        content: const Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.mic_rounded, size: 64, color: Colors.red), SizedBox(height: 12), Text('پیام کوتاه خود را بگویید.', style: TextStyle(fontSize: 18))]),
        actions: [FilledButton.icon(onPressed: () => Navigator.pop(context, true), icon: const Icon(Icons.stop), label: const Text('پایان ضبط'))],
      ));
      if (stop == true) {
        final saved = await recorder.stop();
        if (saved != null) {
          await _saveReminderSettings(ReminderSettings(mode: ReminderMode.recordedVoice, voicePath: saved));
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('صدای شما ذخیره شد.')));
        }
      } else {
        await recorder.stop();
      }
    } finally {
      await recorder.dispose();
    }
  }

  Future<void> _playVoice() async {
    final path = reminderSettings.voicePath;
    if (path == null) return;
    await _voicePlayer.play(DeviceFileSource(path));
  }

  @override
  void dispose() {
    _voicePlayer.dispose();
    super.dispose();
  }

}


class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key, required this.history, required this.onClear});

  final List<Map<String, dynamic>> history;
  final Future<void> Function() onClear;

  String _faDate(String key) {
    final p = key.split('-');
    if (p.length != 3) return key;
    return '${p[2]}/${p[1]}/${p[0]}';
  }

  @override
  Widget build(BuildContext context) {
    final sorted = [...history]..sort((a, b) => (b['consumedAt'] ?? '').toString().compareTo((a['consumedAt'] ?? '').toString()));
    final grouped = <String, List<Map<String, dynamic>>>{};
    for (final item in sorted) {
      final date = item['date'].toString();
      grouped.putIfAbsent(date, () => []).add(item);
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('تاریخچه مصرف', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: [
            if (history.isNotEmpty)
              IconButton(
                tooltip: 'پاک کردن تاریخچه',
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  final ok = await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('پاک کردن تاریخچه؟'),
                      content: const Text('تمام سوابق مصرف ثبت‌شده حذف می‌شوند.'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
                        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف همه')),
                      ],
                    ),
                  );
                  if (ok == true) {
                    await onClear();
                    if (context.mounted) Navigator.pop(context);
                  }
                },
              ),
          ],
        ),
        body: history.isEmpty
            ? const Center(child: Text('هنوز مصرفی ثبت نشده است.'))
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Card(
                    elevation: 0,
                    child: ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.check)),
                      title: const Text('سوابق مصرف دارو', style: TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${history.length} نوبت مصرف ثبت شده'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  ...grouped.entries.map((entry) => Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: Text(_faDate(entry.key), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                          ),
                          ...entry.value.map((item) => Card(
                                elevation: 0,
                                margin: const EdgeInsets.only(bottom: 8),
                                child: ListTile(
                                  leading: const Icon(Icons.check_circle, color: Colors.green),
                                  title: Text(item['medicineName'].toString(), style: const TextStyle(fontWeight: FontWeight.bold)),
                                  subtitle: Text('${item['dose']} ${item['unit']} • ساعت ${item['time']}'),
                                  trailing: Text(
                                    _clock(item['consumedAt'].toString()),
                                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                                  ),
                                ),
                              )),
                        ],
                      )),
                ],
              ),
      ),
    );
  }

  String _clock(String iso) {
    final d = DateTime.tryParse(iso);
    if (d == null) return '';
    return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }
}

class MedicineDialog extends StatefulWidget {
  const MedicineDialog({super.key, this.initial});
  final Medicine? initial;

  @override
  State<MedicineDialog> createState() => _MedicineDialogState();
}

class _MedicineDialogState extends State<MedicineDialog> {
  late final TextEditingController name;
  late final TextEditingController dose;
  late final TextEditingController unit;
  late List<TimeOfDay> times;
  String? photoPath;

  @override
  void initState() {
    super.initState();
    final m = widget.initial;
    name = TextEditingController(text: m?.name ?? '');
    dose = TextEditingController(text: m?.dose ?? '1');
    unit = TextEditingController(text: m?.unit ?? 'قرص');
    times = (m?.times ?? ['08:00']).map(_parseTime).toList();
    photoPath = m?.photoPath;
  }

  TimeOfDay _parseTime(String value) {
    final p = value.split(':');
    return TimeOfDay(hour: int.parse(p[0]), minute: int.parse(p[1]));
  }

  String _formatTime(TimeOfDay t) => '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  @override
  void dispose() {
    name.dispose();
    dose.dispose();
    unit.dispose();
    super.dispose();
  }

  Future<void> _addTime() async {
    final picked = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 8, minute: 0));
    if (picked == null) return;
    if (times.any((t) => t.hour == picked.hour && t.minute == picked.minute)) return;
    setState(() {
      times.add(picked);
      times.sort((a, b) => (a.hour * 60 + a.minute).compareTo(b.hour * 60 + b.minute));
    });
  }

  Future<void> _pickPhoto() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80, maxWidth: 1000);
    if (image != null) setState(() => photoPath = image.path);
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.initial != null;
    return AlertDialog(
      title: Text(editing ? 'ویرایش دارو' : 'افزودن دارو', textAlign: TextAlign.center),
      content: SingleChildScrollView(
        child: Column(
          children: [
            if (photoPath != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Image.file(File(photoPath!), width: 110, height: 110, fit: BoxFit.cover),
              )
            else
              Container(
                width: 110,
                height: 110,
                decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(14)),
                child: const Icon(Icons.medication_rounded, color: _blue, size: 46),
              ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _pickPhoto,
              icon: const Icon(Icons.photo_camera_outlined),
              label: Text(photoPath == null ? 'انتخاب عکس دارو' : 'تغییر عکس دارو'),
            ),
            if (photoPath != null)
              TextButton.icon(onPressed: () => setState(() => photoPath = null), icon: const Icon(Icons.delete_outline), label: const Text('حذف عکس')),
            const SizedBox(height: 8),
            TextField(controller: name, decoration: const InputDecoration(labelText: 'نام دارو', hintText: 'مثلاً متفورمین')),
            const SizedBox(height: 10),
            TextField(controller: dose, decoration: const InputDecoration(labelText: 'مقدار مصرف', hintText: 'مثلاً 500'), keyboardType: TextInputType.number),
            const SizedBox(height: 10),
            TextField(controller: unit, decoration: const InputDecoration(labelText: 'واحد', hintText: 'قرص، mg، میلی‌لیتر...')),
            const SizedBox(height: 16),
            Align(
              alignment: Alignment.centerRight,
              child: Text('ساعت‌های مصرف', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ...times.map((t) => InputChip(
                      label: Text(_formatTime(t)),
                      onPressed: () async {
                        final picked = await showTimePicker(context: context, initialTime: t);
                        if (picked == null) return;
                        setState(() {
                          final index = times.indexOf(t);
                          times[index] = picked;
                          times.sort((a, b) => (a.hour * 60 + a.minute).compareTo(b.hour * 60 + b.minute));
                        });
                      },
                      onDeleted: times.length > 1 ? () => setState(() => times.remove(t)) : null,
                    )),
                ActionChip(label: const Text('+ ساعت جدید'), onPressed: _addTime),
              ],
            ),
            const SizedBox(height: 6),
            const Align(
              alignment: Alignment.centerRight,
              child: Text('می‌توانید برای یک دارو چند ساعت در روز تعیین کنید.', style: TextStyle(fontSize: 12, color: Colors.grey)),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
        FilledButton(
          onPressed: () {
            if (name.text.trim().isEmpty || times.isEmpty) return;
            final id = widget.initial?.id ?? DateTime.now().millisecondsSinceEpoch.remainder(21474836);
            Navigator.pop(
              context,
              Medicine(
                id: id,
                name: name.text.trim(),
                dose: dose.text.trim(),
                unit: unit.text.trim(),
                times: times.map(_formatTime).toList()..sort(),
                photoPath: photoPath,
              ),
            );
          },
          child: Text(editing ? 'ذخیره تغییرات' : 'ذخیره'),
        ),
      ],
    );
  }
}
